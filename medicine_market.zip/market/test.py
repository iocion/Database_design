from datetime import datetime
print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))