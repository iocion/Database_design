## 数据库课设
运行方式
```bash
  cd Database_design
  pip install -r requirements.txt
  python run.py
```
配置自己的数据库sqlalchemy
mysql🏅
